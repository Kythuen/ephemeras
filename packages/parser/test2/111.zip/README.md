# @ephemeras/compiler

Parser template files with data.

## Documentation

Please refer to the [documentation](https://kythuen.github.io/ephemeras/complier).

## License

MIT License &copy; 2023-PRESENT [Kythuen](https://github.com/Kythuen)